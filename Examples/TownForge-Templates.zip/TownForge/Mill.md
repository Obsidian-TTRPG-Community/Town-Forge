---
type: inn
subtype: "{{subtype}}"
size: "{{size}}"
town: "{{town}}"
---
# {{name}}

> [!info] {{type}} in {{town}}

A {{type}} on the out-skirts of {{town}}.

<%*  
const api = app.plugins.plugins["randomness"].api;  
const shop = await api.rollUnscoped("TF-Mill", {  
promptValues: {  
town: "{{town}}",  
shopType: "{{type}}",  
shopName: "{{name}}"  
}  
});  
tR += shop.result;  
%>
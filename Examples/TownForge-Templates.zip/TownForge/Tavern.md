---
type: inn
subtype: "{{subtype}}"
size: "{{size}}"
town: "{{town}}"
---
# {{name}}
> [!info] {{type}} in {{town}}

A {{type}} on the streets of {{town}}.

<%*
const api = app.plugins.plugins["randomness"].api;
const fm = tp.frontmatter;
const result = await api.rollUnscoped("TF-Tavern", {
  promptValues: { town: fm.town, shopType: fm.type, shopName: fm.name }
});
tR += result.result;
%>
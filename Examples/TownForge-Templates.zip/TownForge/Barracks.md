---
type: inn
subtype: "{{subtype}}"
size: "{{size}}"
town: "{{town}}"
---
# {{name}}

> [!info] {{type}} in {{town}}

A {{type}} on the streets of {{town}}.

<%*  
const api = app.plugins.plugins["randomness"].api;  
const shop = await api.rollUnscoped("TF-Barracks", {  
promptValues: {  
town: "{{town}}",  
shopType: "{{type}}",  
shopName: "{{name}}"  
}  
});  
tR += shop.result;  
%>
Town Forge place-note templates (portrait edition)
==================================================

One template per pin type. Each fills the note body with rolled
content that MATCHES the name/subtype Town Forge chose - shopkeepers,
commanders, priests and patrons arrive with names, portraits and
coherent descriptions.

Requirements
- Randomness (with its Fantasy Hub content + Fantasy Portrait Pack
  installed: Settings -> Randomness -> the two Install buttons)
- Templater, with "Trigger Templater on new file creation" ON
  (per-device setting)

Easiest install: don't use this zip at all - Randomness's
"Install Fantasy Hub content" button installs these templates AND
points Town Forge's template folder at them automatically. This zip
is the offline/manual copy: extract it and set Town Forge ->
Template folder to the extracted TownForge folder (forward slashes).

Templates degrade gracefully: without Randomness they emit plain
notes; without a portrait pack, text only.

Town Forge place-note templates + pins (portrait edition)
=========================================================

This pack contains, for each of the 15 town pin types:
  * a place-note template (Castle.md, Inn.md, Thief Guild.md, ...)
  * "Custom Pins.json" - the 15 matching pin types, with icons that
    render in TTRPG Tools - Maps out of the box.

------------------------------------------------------------------
SETUP - DO THESE IN ORDER
------------------------------------------------------------------

STEP 1 - Install & enable the plugins (Community plugins)
  * Randomness        (generators + NPC portraits)
  * Templater         (runs the templates)
  * Town Forge        (builds the town + map)
  * TTRPG Tools - Maps (displays the map and its pin icons)
  In Templater settings, turn ON
  "Trigger Templater on new file creation".

STEP 2 - Give TTRPG Tools - Maps its icons  (REQUIRED FIRST -
         without this, every pin shows a plain red dot)
  Settings -> TTRPG Tools - Maps, then click BOTH:
     [Download font awesome free]
     [Download rpg awesome]
  This creates the ZoomMap/SVGs folder the pin icons come from.

STEP 3 - Inject the pin config into Town Forge
  Settings -> Town Forge -> pin types ->
  expand "Advanced: edit pin types as JSON" ->
  paste the entire contents of "Custom Pins.json" ->
  click "Apply JSON".
  (This REPLACES your pin types with the 15 that match these
  templates. All 15 icons resolve from the Step 2 packs.)

STEP 4 - Point Town Forge at these templates
  Easiest: in Randomness, click "Install Fantasy Hub content" -
  it copies these templates in AND sets Town Forge's template
  folder automatically.
  Manual: extract this TownForge folder into your vault and set
  Town Forge -> Template folder to it (use forward slashes).

STEP 5 - Generate & view
  Build a town in Town Forge with map export ON, then open the
  exported map note. TTRPG Tools - Maps draws each pin with its
  icon and links it to the generated place note.

------------------------------------------------------------------
Notes
  * Templates degrade gracefully: without Randomness they emit
    plain notes; without a portrait pack, text only.
  * Icons: 14 come from Font Awesome Free 6.4.0, 1 (stable) from
    RPG Awesome - both installed in Step 2.

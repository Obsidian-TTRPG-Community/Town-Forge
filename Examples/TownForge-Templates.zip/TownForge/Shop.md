---
type: shop
subtype: "{{subtype}}"
size: "{{size}}"
town: "{{town}}"
---
# {{name}}
> [!info] {{subtype}} {{type}} in {{town}}
<%*
const api = app.plugins.plugins["randomness"].api;
// Build a body that MATCHES the name + subtype Town Forge already chose.
// No re-rolling the name, no rename — the note keeps the name Town Forge gave it.
const shop = await api.rollUnscoped("TF-ShopByType", {
  promptValues: {
    town: "{{town}}",
    shopType: "{{subtype}}",
    shopName: "{{name}}",
    size: "{{size}}"
  }
});
tR += shop.result;
%>